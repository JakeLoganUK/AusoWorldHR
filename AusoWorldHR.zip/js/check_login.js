if (localStorage.getItem('othKey') == undefined) {
    location.replace('index.html')
}